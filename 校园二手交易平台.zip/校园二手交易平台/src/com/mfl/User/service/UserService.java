package com.mfl.User.service;

import com.mfl.User.dao.UserDao;
import com.mfl.User.domain.User;
//业务层功能的实现
public class UserService {

	//建立与dao之间的联系
	UserDao userDao=new UserDao();
	/**
	 * 登录验证
	 * @param form
	 */
	public User login(User form)throws UserException{
		User user=userDao.findByUsername(form.getUsername());
		if(user==null){
			throw new UserException("该用户不存在");
		}
		if(!user.getPassword().equals(form.getPassword())){
			throw new UserException("密码不正确");
		}
		if(!user.isState()){
			throw new UserException("该用户尚未激活");
		}
		return user;
	}
	/**
	 * 注册功能实现
	 * @param form
	 * @throws UserException
	 */
	public void regist(User form)throws UserException{
		User user=userDao.findByUsername(form.getUsername());
		if(user!=null){
			throw new UserException("该用户名已被注册");
		}
		user=userDao.findByEmail(form.getEmail());
		
		if(user!=null){
			throw new UserException("该邮箱已被注册");
		}
		userDao.add(form);//需要注意的是，最后加的是form
	}
	/**
	 * 激活功能实现
	 * @param form
	 */
	public void active(String code)throws UserException{
		//根据激活码找到在数据库中的该用户
		User user=userDao.findByCode(code);
		//如果该用户不存在的话
		if(user==null){
			throw new UserException("该用户尚未激活");
		}
		if(user.isState()){
			throw new UserException("请不要重复激活");
		}
		//运行到这里说明用户激活正常
		//这里一切要与dao打交道
		userDao.updateState(user.getUid(), true);
		
	}
	public String findPassword(String username,String email)throws UserException{
		User user=userDao.findByUsername(username);
		if(user==null){
			throw new UserException("该用户不存在");
		}
		if(!user.getEmail().equals(email)){
			throw new UserException("Email错误");
		}
		String password=user.getPassword();
		return password;//最后将找到的密码返回会去
	}
}
