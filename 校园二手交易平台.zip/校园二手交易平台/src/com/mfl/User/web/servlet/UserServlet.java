package com.mfl.User.web.servlet;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.mail.Mail;
import cn.itcast.mail.MailUtils;
import cn.itcast.servlet.BaseServlet;

import com.mfl.User.domain.User;
import com.mfl.User.service.UserException;
import com.mfl.User.service.UserService;
import com.mfl.utils.MyUtils;

public class UserServlet extends BaseServlet {

	UserService userService=new UserService();
	/**
	 * 这边要重写的是登录验证方法
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//将表单数据封装到User中
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		User user=new User();
		user.setUsername(username);
		user.setPassword(password);
		//将产生的错误放进map容器中
		Map<String,String> errors=new HashMap<String,String>();
		//校验用户名
		if(username==null || username.trim().isEmpty()){
			errors.put("username", "用户名不能为空！");
		}else if(username.length()<3){
			errors.put("username", "长度不规范！");
		}
		if(password==null || password.trim().isEmpty()){
			errors.put("password", "密码不能为空！");
		}else if(password.length()<3){
			errors.put("password", "长度不规范！");
		}
		//当容器里面放了对象的时候说明有错误产生
		if(errors.size()>0){
			//将map容器封装到request中
			request.setAttribute("errors", errors);
			//将表单数据也封装进去
			request.setAttribute("form", user);
			//之后直接转发
			return "f:/jsps/user/login.jsp";
		}
		try{
			User use=userService.login(user);
			//这里面需要检查用户是否处于登录状态，所以用一个session来检查
			request.getSession().setAttribute("session_user",use );
			/**
			 * 登录成功之后发一辆购物车
			 * 
			 */
			//request.getSession().setAttribute("cart", new Cart());
			return "f:/index.jsp";
		}catch(UserException e){
			request.setAttribute("msg", e.getMessage());
			request.setAttribute("form", user);
			return "f:/jsps/user/login.jsp";
		}
	}
	/**
	 * 退出功能实现
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	//退出其实就是将登录值给用户的session拿过来杀死
	public String quit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//如果退出的话直接将session拿来杀死就OK
		request.getSession().invalidate();//这就射死了session
		return "f:/jsps/user/login.jsp";
	}
	/**
	 * 注册验证方法
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String regist(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//先是获取表单数据
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		User form=new User();
		form.setUsername(username);
		form.setPassword(password);
		form.setEmail(email);
		//设置uid和code
		form.setUid(MyUtils.getUUID());
		form.setCode(MyUtils.getUUID()+MyUtils.getUUID());//设置成一个64为长度的
		
		Map<String,String> errors=new HashMap<String,String>();
		//校验用户名
		if(username==null || username.trim().isEmpty()){
			errors.put("username", "用户名不能为空！");
		}else if(username.length()<3){
			errors.put("username", "长度不规范！");
		}
		if(password==null || password.trim().isEmpty()){
			errors.put("password", "密码不能为空！");
		}else if(password.length()<3){
			errors.put("password", "长度不规范！");
		}
		if(email==null || email.trim().isEmpty()){
			errors.put("email", "Email不能为空");
		}else if(!email.matches("\\w+@\\w+\\.\\w+")){
			errors.put("email", "Email格式错误");
		}
		//转发信息,也就是在发生错误的情况下这个步骤回执信
		if(errors.size()>0){
			request.setAttribute("errors", errors);
			request.setAttribute("form", form);
			return "f:/jsps/user/regist.jsp";
		}
		//然后调用Service层的regist方法
		try {
			userService.regist(form);
//			return "f:/jsps/user/login.jsp";	
					
		} catch (UserException e) {
			request.setAttribute("msg", e.getMessage());
			request.setAttribute("form", form);
			return "f:/jsps/user/regist.jsp";
		}
		//现在就是激活的问题咯
		//注册成功之后就需要激活邮件，激活邮件这一步是需要加载配置文件的
		Properties prps=new Properties();
		prps.load(this.getClass().getClassLoader().getResourceAsStream("email.properties"));
		String host=prps.getProperty("host");//获取主机
		System.out.println(host);
		String uname=prps.getProperty("uname");//获取用户名
		String pwd=prps.getProperty("pwd");//获取密码
		String subject=prps.getProperty("subject");//获取邮件的主题
		System.out.println(subject);
		String from=prps.getProperty("from");//获取发件人
		String to=form.getEmail();//获取收件人
		String content=prps.getProperty("content");//获取邮件正文
		//content里面有一个占位符，这是模板化的对象处理器
		content=MessageFormat.format(content, form.getCode());
		System.out.println(content);
		//创建发送邮件的Session
		Session session=MailUtils.createSession(host, uname, pwd);
		Mail mail=new Mail(from, to, subject, content);
		try {
			//发送邮件
			MailUtils.send(session, mail);
		} catch (MessagingException e) {
			
		}
		request.setAttribute("msg", "恭喜注册成功，请到邮箱激活！");
		return "f:/jsps/msg.jsp";
	}
	public String active(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//从返回来的页面中获取激活码
		String code=request.getParameter("code");
		try {
			userService.active(code);
			request.setAttribute("msg","激活已经成功");
		} catch (UserException e) {
			request.setAttribute("msg", e.getMessage());
		}
		
		return "f:/jsps/msg.jsp";
	}
	/**
	 * 召回密码
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	
	public String findPassword(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username=request.getParameter("username");
		String email=request.getParameter("email");
		User form=new User();
		form.setUsername(username);
		form.setEmail(email);
		try {
			String password=userService.findPassword(username, email);
			request.setAttribute("msg", "成功召回密码，密码为："+password);
			request.setAttribute("form", form);
		} catch (UserException e) {
			request.setAttribute("msg", e.getMessage());
			request.setAttribute("form", form);
		}
		return "f:/jsps/user/findpsw.jsp";
	}
}
