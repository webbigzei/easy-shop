package com.mfl.utils;

import java.util.Date;

public class Testutils {

	public static void main(String[] args) {
		Date date=new Date();
	
		System.out.println(date.toLocaleString());
		String date1=date.toLocaleString().split(" ")[0];
		String time1=date.toLocaleString().split(" ")[1];
		System.out.println(date1);
		System.out.println(time1);
	}
}
