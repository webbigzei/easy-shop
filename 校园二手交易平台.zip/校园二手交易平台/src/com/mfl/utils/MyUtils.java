package com.mfl.utils;

import java.util.UUID;

public class MyUtils {

	public static String getUUID(){
		String uuid=UUID.randomUUID().toString().replace("-", "");
		return uuid;
	}
}
