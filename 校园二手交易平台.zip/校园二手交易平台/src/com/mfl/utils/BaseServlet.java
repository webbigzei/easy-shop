package com.mfl.utils;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * 这边定义一个超类，用后面的Servlet来继承这个超类，做一些操作
 * @author cool@MM
 *
 */
public abstract class BaseServlet extends HttpServlet {
 
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//获取用户传过来的名为method的参数
		String methodName=request.getParameter("method");
		if(methodName==null||methodName.trim().isEmpty()){
			throw new RuntimeException("您想调用的方法没有找到！");
		}
		//调用该方法进行处理
		/**
		 * 但是一般时候我们是不知道有哪些方法，也就是说
		 * 方法名太多会给我们造成麻烦，所以这边就用反射的方式来获取
		 * 方法名
		 */
		Class c=this.getClass();
		Method method=null;
		try {
			method=c.getMethod(methodName, 
					HttpServletRequest.class,HttpServletResponse.class);
		} catch (Exception e) {
			throw new RuntimeException("您想要的方法内部抛出了异常没有找到！");
		}
		
		try {
			//反射调用方法。一定要记住咯
			String result=(String) method.invoke(this, request,response);
			if(result==null)return;
			if(result.contains(":")){
				int index=result.indexOf(":");
				String forString=result.substring(0, index);
				String path=result.substring(index+1, result.length());
				if(forString.equalsIgnoreCase("f")){
					request.getRequestDispatcher(path).forward(request, response);
				}else if(forString.equalsIgnoreCase("r")){
					response.sendRedirect(request.getContextPath()+path);
				}else{
					throw new RuntimeException("对不起，还没有达到您想要的那个版本");
				}
			}else{
				response.sendRedirect(result);
			}
		} catch (Exception e1) {
			throw new RuntimeException(e1);
		}
		
		
	}
			
}
