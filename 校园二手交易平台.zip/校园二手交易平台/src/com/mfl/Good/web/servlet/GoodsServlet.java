package com.mfl.Good.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.servlet.BaseServlet;

import com.mfl.Good.domain.Goods;
import com.mfl.Good.service.GoodsService;

/**
 * Servlet implementation class GoodsServlet
 */
@WebServlet("/GoodsServlet")
public class GoodsServlet extends BaseServlet {

	GoodsService goodservice=new GoodsService();
	/**
	 * 查询所有商品，将其列出来
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("执行到fingAll Servlet咯");
		request.setAttribute("goodslist", goodservice.findAll());
		return "f:/jsps/goods/list.jsp";
	}
	
	/**
	 * 按分类查询所有商品
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findByCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String cname=request.getParameter("cid");
		if(cname.equals("1")){
			request.setAttribute("goodslist", goodservice.findByCategory("校园代步"));
		}else if(cname.equals("2")){
			request.setAttribute("goodslist", goodservice.findByCategory("手机"));
		}else if(cname.equals("3")){
			request.setAttribute("goodslist", goodservice.findByCategory("电脑"));
		}else if(cname.equals("4")){
			request.setAttribute("goodslist", goodservice.findByCategory("数码配件"));
		}else if(cname.equals("5")){
			request.setAttribute("goodslist", goodservice.findByCategory("数码"));
		}else if(cname.equals("6")){
			request.setAttribute("goodslist", goodservice.findByCategory("电器"));
		}else if(cname.equals("7")){
			request.setAttribute("goodslist", goodservice.findByCategory("运动健身"));
		}else if(cname.equals("8")){
			request.setAttribute("goodslist", goodservice.findByCategory("衣物伞帽"));
		}else if(cname.equals("9")){
			request.setAttribute("goodslist", goodservice.findByCategory("图书教材"));
		}else if(cname.equals("10")){
			request.setAttribute("goodslist", goodservice.findByCategory("租赁"));
		}else if(cname.equals("11")){
			request.setAttribute("goodslist", goodservice.findByCategory("生活娱乐"));
		}else{
			request.setAttribute("goodslist", goodservice.findByCategory("其他"));
		}
		System.out.println(cname);
		//request.setAttribute("goodslist", goodservice.findByCategory(cname));
		return "f:/jsps/goods/list.jsp";
	}
	/**
	 * 按关键字查询商品
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findByKey(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String key=request.getParameter("key");
	
		System.out.println(key);
		List<Goods> list=goodservice.findByKey(key);

		for (Goods goods : list) {
			System.out.println(goods.getCategory());
		}
		request.setAttribute("goodslist", list);
		System.out.println("执行到这里");
		return "f:/jsps/goods/list.jsp";
	}
	/**
	 * 加载商品
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String load(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String gid=request.getParameter("gid");
		request.setAttribute("single_goods", goodservice.load(gid));
		return "f:/jsps/goods/desc.jsp";
	}
	/**
	 * 仅仅是一个测试方法
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findMyName(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name=request.getParameter("myname");
		System.out.println(name);
		return "";
	}

}
