package com.mfl.Good.domain;

import com.mfl.User.domain.User;

/*
 * 这是货物的JavaBean类
 */
public class Goods {

	private String gid;
	private String gname;
	private String describe;
	private String exchange_place;
	private String price;
	private  String category;
	private String contect_way;
	private String seller;
	private String image;
	
	public String getGid() {
		return gid;
	}
	public void setGid(String gid) {
		this.gid = gid;
	}
	public String getGname() {
		return gname;
	}
	public void setGname(String gname) {
		this.gname = gname;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String getExchange_place() {
		return exchange_place;
	}
	public void setExchange_place(String exchange_place) {
		this.exchange_place = exchange_place;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getContect_way() {
		return contect_way;
	}
	public void setContect_way(String contect_way) {
		this.contect_way = contect_way;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
}





















