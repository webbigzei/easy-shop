package com.mfl.Good.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.itcast.jdbc.TxQueryRunner;
import cn.itcast.utils.CommonUtils;

import com.mfl.User.dao.UserDao;
import com.mfl.User.domain.User;
import com.mfl.Good.domain.Goods;

public class GoodsDao {

	QueryRunner qr=new TxQueryRunner();
	/**
	 * 查询出所有的货物
	 * @return
	 */
	public List<Goods> findAll(){
		try{
			System.out.println("执行到GoodDao中的findAll咯");
			String sql="select * from tb_goods";
			System.out.println("如果sql语句没有出错的话会执行到这里");
			return qr.query(sql, new BeanListHandler<Goods>(Goods.class));
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 按分类查询图书
	 * @param cid
	 * @return
	 */
	public List<Goods> findByCategory(String cname){
		try{
			String sql="select * from tb_goods where category=?";
			return qr.query(sql, new BeanListHandler<Goods>(Goods.class),cname);
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 关键字查询
	 * @param key
	 * @return
	 */
	public List<Goods> findByKey(String key){
		try{
			//这边就使用模糊查询
			String sql="select * from tb_goods where gname like ?";
			return qr.query(sql, new BeanListHandler<Goods>(Goods.class),"%"+key+"%");
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 加载货物
	 * @param gid
	 * @return
	 */
	public Goods load(String gid){
		try{
			String sql="select * from tb_goods where gid=?";
			return qr.query(sql, new BeanHandler<Goods>(Goods.class), gid);//这样这边才会设置category到Goods中
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 根据gid查出一个对象，单值这里面是
	 * @param gid
	 * @return
	 */
	public Goods loadSingle(String gid){
		try{
			String sql="select * from tb_goods where gid=?";
			return qr.query(sql, new BeanHandler<Goods>(Goods.class),gid);
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 按目录id查出该目录下面的货物的数量
	 * @param cid
	 * @return
	 */
	public int getCountByCategory(String cid){
		try{
			String sql="select count(*) from tb_goods where category=?";
			Number num=(Number)qr.query(sql, new ScalarHandler(), cid);
			return num.intValue();
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 添加货物
	 * @param good
	 */
	public void add(Goods good) {

		try{
			String sql="insert into tb_goods values(?,?,?,?,?,?,?,?,?)";
			Object[] params={good.getGid(), good.getGname(),good.getDescribe(),
					good.getExchange_place(),
					good.getPrice(),good.getCategory(),good.getContect_way()
					,good.getImage(),good.getSeller()};
			qr.update(sql, params);
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
		
	}
}
