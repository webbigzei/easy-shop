package com.mfl.Good.service;

import java.util.List;

import com.mfl.Good.dao.GoodsDao;
import com.mfl.Good.domain.Goods;

/**
 * 业务逻辑层
 * @author cool@MM
 *
 */
public class GoodsService {

	GoodsDao goodsDao=new GoodsDao();
	/**
	 * 查询所有的货物
	 * @return
	 */
	public List<Goods> findAll(){
		return goodsDao.findAll();
	}
	/**
	 * 根据关键字查询货物
	 * @param key
	 * @return
	 */
	public List<Goods> findByKey(String key){
		return goodsDao.findByKey(key);
	}
	/**
	 * 根据目录查询货物
	 * @param cid
	 * @return
	 */
	public List<Goods> findByCategory(String cid){
		return goodsDao.findByCategory(cid);
	}
	/**
	 * 加载货物
	 * @param gid
	 * @return
	 */
	public Goods load(String gid){
		return goodsDao.load(gid);
	}
	/**
	 * 增加商品
	 * @param good
	 */
	public void add(Goods good){
		goodsDao.add(good);
	}
	
}
