package com.mfl.message.service;

import java.util.List;

import com.mfl.message.dao.MessageDao;
import com.mfl.message.domain.Message;

/**
 * 业务层
 * @author cool@MM
 *
 */
public class MessageService {

	MessageDao dao=new MessageDao();
	/**
	 * 箱数据库中添加留言信息
	 * @param message
	 */
	public void add(Message message) {
		dao.add(message);
	}
	public List<Message> findByName(String seller) {
		return dao.findByName(seller);
	}
	public void removeMessage(String mid) {
		// TODO Auto-generated method stub
		dao.removeMessage(mid);
	}
}
