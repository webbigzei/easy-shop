package com.mfl.message.dao;

import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.itcast.jdbc.TxQueryRunner;

import com.mfl.message.domain.Message;

/**
 * 数据接口
 * @author cool@MM
 *
 */
public class MessageDao {

	QueryRunner qr=new TxQueryRunner();
	/**
	 * 向数据库中添加留言信息
	 * @param message
	 */
	public void add(Message message) {
		try{
			String sql="insert into tb_message values(?,?,?,?,?,?)";
			Object[] param={message.getMid(),message.getSelller(),
					message.getBuyer(),message.getDate(),message.getTime(),
					message.getMessage()};
			qr.update(sql, param);
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 查找留给该用户的所有留言
	 * @param seller
	 * @return
	 */
	public List<Message> findByName(String seller) {
		try{
			String sql="select * from tb_message where seller=?";
			return qr.query(sql, new BeanListHandler<Message>(Message.class), seller);
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 删除留言
	 * @param mid
	 */
	public void removeMessage(String mid) {

		try{
			String sql="delete from tb_message where mid=?";
			qr.update(sql, mid);
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}

}
