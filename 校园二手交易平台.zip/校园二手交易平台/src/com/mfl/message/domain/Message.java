package com.mfl.message.domain;

import java.util.Date;

public class Message {

	private String mid;
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	private String selller;
	private String buyer;
	private String message;
	private String date;
	private String time;
	public String getSelller() {
		return selller;
	}
	public void setSelller(String selller) {
		this.selller = selller;
	}
	public String getBuyer() {
		return buyer;
	}
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
}
