package com.mfl.message.web.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.utils.CommonUtils;

import com.mfl.message.domain.Message;
import com.mfl.message.service.MessageService;
import com.mfl.utils.BaseServlet;

public class MessageServlet extends BaseServlet {

	
	MessageService service=new MessageService();
	/**
	 * 这里就是起一个转发的作用，用作控制器
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String toLeaving_msg(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String seller=request.getParameter("seller");
		request.setAttribute("toseller", seller);
		return "f:/jsps/user/leaving_msg.jsp";
	}
	
	public String saveMessage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Message message=new Message();
//		String seller=request.getParameter("seller");
		String seller = new String(request.getParameter("seller").getBytes("ISO-8859-1"),"utf-8") ;
		message.setSelller(seller);
		
//		String buyer=request.getParameter("buyer");
		String buyer = new String(request.getParameter("buyer").getBytes("ISO-8859-1"),"utf-8") ;
		message.setBuyer(buyer);
		
//		String msg=request.getParameter("message");
		String msg = new String(request.getParameter("message").getBytes("ISO-8859-1"),"utf-8") ;
		System.out.println("转成gbk之后的消息为"+msg);
		message.setMessage(msg);
		System.out.println(message.getMessage());
//		System.out.println(message.getBuyer());
		//设置mid
		message.setMid(CommonUtils.uuid());
		Date date=new Date();
		String date1=date.toLocaleString().split(" ")[0];
		String time1=date.toLocaleString().split(" ")[1];
		message.setDate(date1);
		message.setTime(time1);
		service.add(message);
		return "f:/jsps/user/leaving_msg.jsp";
	}
	/**
	 * 根据用户名查找留言
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findMessageByName(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String seller=request.getParameter("seller");
		List<Message> message=service.findByName(seller);
		request.setAttribute("messagelist", message);
		return "f:/jsps/user/message.jsp";
		
	}
	
	public String removeMessage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String mid=request.getParameter("cid");//得到留言唯一的编号
		service.removeMessage(mid);
		return "f:/jsps/user/user.jsp";
	}
}
