package com.mfl.MyGoods.service;

import java.util.List;

import com.mfl.Good.domain.Goods;
import com.mfl.MyGoods.dao.MyGoodsDao;
import com.mfl.MyGoods.domain.MyGoods;
import com.mfl.User.domain.User;

public class MyGoodsService {

	MyGoodsDao dao=new MyGoodsDao();
	/**
	 * 根据用户名查找用户
	 * @param username
	 * @return
	 */
	public User findByUsername(String username){
		return dao.findByUsername(username);
	}
	/**
	 * 根据卖主查找该用户发表的所有商品
	 * @param seller
	 * @return
	 */
	public List<MyGoods> findBySeller(String seller){
		return dao.findBySeller(seller);
	}
	/**
	 * 加载货物
	 * @param gid
	 * @return
	 */
	public Goods load(String gid){
		return dao.load(gid);
	}
	/**
	 * 添加货物
	 * @param good
	 */
	public void add(MyGoods good) {
		dao.add(good);
	}
}
