package com.mfl.MyGoods.web.servlet;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import cn.itcast.utils.CommonUtils;

import com.mfl.MyGoods.domain.MyGoods;
import com.mfl.MyGoods.service.MyGoodsService;

public class AddGoodsServlet extends HttpServlet {

	MyGoodsService goodsService=new MyGoodsService();
	//处理上传文件
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	request.setCharacterEncoding("utf-8");
	response.setContentType("text/html;charset=utf-8");
	
	//这里是解决上传图片文件得地方
	//得到工厂
	DiskFileItemFactory factory=new DiskFileItemFactory();
	//得到解析器
	ServletFileUpload upload=new ServletFileUpload(factory);
	//使用解析器去解析request对象，得到fileItem
//	upload.setFileSizeMax(20 * 1024);
	try {
		List<FileItem> fileItemList=upload.parseRequest(request);
		/**
		 * 把fileList中的数据封装到Book对象中
		 * 首先需要将此对象装换成map集合
		 */
		Map<String,String> map=new HashMap<String ,String>();
		//遍历集合
		for(FileItem fileItem:fileItemList){
			//判断表单字段是否是普通字段,然后放入map集合中
			if(fileItem.isFormField()){
				map.put(fileItem.getFieldName(), fileItem.getString("UTF-8"));
			}
		}
			MyGoods book=CommonUtils.toBean(map, MyGoods.class);
			
			book.setGid(CommonUtils.uuid());
			/**
			 * 保存上传的文件
			 * 1.保存的目录
			 * 2.保存的文件名称
			 */
			//得到保存目录
			String savepath=this.getServletContext().getRealPath("/goods_image");
			System.out.println(savepath);
			String filename=CommonUtils.uuid()+"_"+fileItemList.get(5).getName();
			System.out.println(filename);
			//用文件路径和文件名创建文件
			File file=new File(savepath,filename);
			//将文件写到磁盘中
			fileItemList.get(5).write(file);
			//调用Book对象，把image设置到book里面
			book.setImage("./goods_image/"+filename);
			String uname=request.getParameter("seller");
			book.setSeller(uname);
			//调用bookservice 完成保存
			if(book.getGname()==null||book.getGname().trim().isEmpty()){
				request.setAttribute("msg1", "商品名称不能为空");
				request.getRequestDispatcher("/jsps/goods/upload.jsp").forward(request, response);
				return;
			}else if(book.getDescribe()==null || book.getDescribe().trim().isEmpty()){
				request.setAttribute("msg2", "商品描述不能为空");
				request.getRequestDispatcher("/jsps/goods/upload.jsp").forward(request, response);
			}else if(book.getExchange_place()==null|| book.getExchange_place().trim().isEmpty()){
				request.setAttribute("msg3", "交易地址不能为空");
				request.getRequestDispatcher("/jsps/goods/upload.jsp").forward(request, response);
			}else if(book.getPrice()==null || book.getPrice().trim().isEmpty()){
				request.setAttribute("msg4", "商品价格不能为空");
				request.getRequestDispatcher("/jsps/goods/upload.jsp").forward(request, response);
			}else if(book.getCategory()==null || book.getCategory().trim().isEmpty()){
				request.setAttribute("msg5", "商品分类不能为空");
				request.getRequestDispatcher("/jsps/goods/upload.jsp").forward(request, response);
			}else if(book.getContect_way()==null || book.getContect_way().trim().isEmpty()){
				request.setAttribute("msg6", "联系方式不能为空");
				request.getRequestDispatcher("/jsps/goods/upload.jsp").forward(request, response);
			}else{
				goodsService.add(book);
			}
			//转发到图书列表
			System.out.println(book.getSeller());
			System.out.println(book.getGname());
			System.out.println(book.getSeller()+","+book.getExchange_place()+","+book.getCategory()+","+book.getContect_way()
					+","+book.getDescribe()+","
					+book.getGid()+","+book.getGname()+","+book.getImage()+","+book.getPrice());
			request.getRequestDispatcher("").forward(request, response);
	} catch (Exception e) {
		
	}
	
	}
	
	


}
