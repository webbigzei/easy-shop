package com.mfl.MyGoods.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.servlet.BaseServlet;
import cn.itcast.utils.CommonUtils;

import com.mfl.MyGoods.domain.MyGoods;
import com.mfl.MyGoods.service.MyGoodsService;

public class MyGoodsServlet extends BaseServlet{

	
	MyGoodsService goodsService=new MyGoodsService();
	/**
	 * 查找用户资料
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findByUsername(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String username=request.getParameter("username");
//		String username = new String(request.getParameter("username").getBytes("ISO-8859-1"),"utf-8") ;
//		System.out.println(uname);
		System.out.println("用户名为："+username);
		request.setAttribute("Mymsg",goodsService.findByUsername(username) );
		List<MyGoods> list=goodsService.findBySeller(username);
		if(list==null || list.size()==0){
			request.getSession().setAttribute("seller_msg", "还用户还没有上传任何商品");
		}else{
			request.getSession().setAttribute("seller_contect",goodsService.findBySeller(username).get(0) );
		}
		return "f:/jsps/user/user.jsp";
	}
	/**
	 * 根据卖主名找出所有该卖主上传的商品
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findBySeller(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String seller=request.getParameter("seller");
		request.setAttribute("goodslist", goodsService.findBySeller(seller));
		return "f:/jsps/user/mygoods.jsp";
	}
	
	
	public String upload(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		MyGoods goods=CommonUtils.toBean(request.getParameterMap(), MyGoods.class);
		System.out.println(goods.getCategory());
		System.out.println(goods.getContect_way());
		System.out.println(goods.getDescribe());
		return "";
	}
	
	
	
}
