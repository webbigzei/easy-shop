package com.mfl.MyGoods.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import cn.itcast.jdbc.TxQueryRunner;

import com.mfl.Good.domain.Goods;
import com.mfl.MyGoods.domain.MyGoods;
import com.mfl.User.domain.User;

/**
 * 个人主页
 * @author cool@MM
 *
 */
public class MyGoodsDao {

	QueryRunner qr=new TxQueryRunner();
	
	/**
	 * 根据用户名查找用户的所有资料
	 * @param username
	 * @return
	 */
	public User findByUsername(String  username){
		try{
			String sql="select * from tb_user where username=?";
			return qr.query(sql, new BeanHandler<User>(User.class),username);
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	/**
	 * 按照卖主查找所有的商品资料
	 * @param seller
	 * @return
	 */
	public List<MyGoods> findBySeller(String seller){
		try{
			String sql="select * from tb_goods where seller=?";
			return qr.query(sql, new BeanListHandler<MyGoods>(MyGoods.class),seller);
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	
	
	/**
	 * 加载货物
	 * @param gid
	 * @return
	 */
	public Goods load(String gid){
		try{
			String sql="select * from tb_goods where gid=?";
			return qr.query(sql, new BeanHandler<Goods>(Goods.class), gid);//这样这边才会设置category到Goods中
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * 添加货物
	 * @param good
	 */
	public void add(MyGoods good) {

		try{
			String sql="insert into tb_goods values(?,?,?,?,?,?,?,?,?)";
			Object[] params={good.getGid(), good.getGname(),good.getDescribe(),
					good.getExchange_place(),
					good.getPrice(),good.getCategory(),good.getContect_way()
					,good.getImage(),good.getSeller()};
			qr.update(sql, params);
		}catch(SQLException e){
			throw new RuntimeException(e);
		}
		
	}
}
